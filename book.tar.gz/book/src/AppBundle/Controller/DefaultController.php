<?php

namespace AppBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Response;
use FOS\RestBundle\Controller\Annotations as Rest;
use FOS\RestBundle\Controller\FOSRestController;
use AppBundle\Entity\Livre;
use FOS\RestBundle\View\View;

class DefaultController extends FOSRestController{
     
    /** 
    * @Rest\Get("/books/")
    */
    public function getAction()
    {
        $result = $this->getDoctrine()->getRepository(Livre::class)->findAll();
        if ($result === null)
            return new View("there are no tasks", Response::HTTP_NOT_FOUND);
            return $result;
    }
    /**
    * @Rest\Get("/books/{id}")
    */
    public function getActionByid($id)
    {
        $result = $this->getDoctrine()->getRepository(Livre::class)->find($id);
        if ($result === null)
            return new View("there are no task", Response::HTTP_NOT_FOUND);
            return $result;
    }
 /**
    * @Rest\Get("/books/auteur/{s}")
    */
    public function getActionByAuteur($s)
    {
        
        $result = $this->getDoctrine()->getRepository(Livre::class)->findByTitre($s);
        if ($result === null)
            return new View("there are no books", Response::HTTP_NOT_FOUND);
            return $result;
    }
 /**
     * @Rest\Post("/books")
    */
    public function addBooks(Request $request)
    {
      $titre = $request->get('titre');
      $descriptif = $request->get('descriptif');
      $iSBN = $request->get('iSBN');
      $datededition = $request->get('datededition');

      /*if(empty($titre))
      {
        return new View("NULL VALUES ARE NOT ALLOWED", Response::HTTP_NOT_ACCEPTABLE);
      }*/
      $product = new Livre();
      $product->setTitre($titre);
      $product->setDescriptif($descriptif);
      $product->setISBN($iSBN );
      $product->setDatededition($datededition);
      $em = $this->getDoctrine()->getManager();
      $em->persist($product);
      $em->flush();
        return new View("Task Added Successfully", Response::HTTP_CREATED);
    } 
 
 
    /**
     * @Rest\Delete("/books/{id}")
    */
    public function removeTask(Request $request,$id)
    {
     
      $data = $this->getDoctrine()->getRepository(Livre::class)->find($id);
      if(empty($data))
      {
        return new View("NULL VALUES ARE NOT ALLOWED", Response::HTTP_NOT_FOUND);
      }
      $em = $this->getDoctrine()->getManager();
      $em->remove($data);
      $em->flush();
        return new View("Task removed Successfully", Response::HTTP_CREATED);
    } 
/**
     * @Rest\Put("/books/{id}")
    */
    public function editBooks(Request $request,$id)
    {
        $titre = $request->get('titre');
        $descriptif = $request->get('descriptif');
        $iSBN = $request->get('iSBN');
        $datededition = $request->get('datededition');
      if(empty($task))
      {
        return new View("NULL VALUES ARE NOT ALLOWED", Response::HTTP_NOT_ACCEPTABLE);
      }
      $data = $this->getDoctrine()->getRepository(Livre::class)->find($id);
      if(empty($data))
      {
        return new View("NULL VALUES ARE NOT ALLOWED", Response::HTTP_NOT_FOUND);
      }
      $product->setTitre($titre);
      $product->setDescriptif($descriptif);
      $product->setISBN($iSBN );
      $product->setDatededition($datededition);
      $em = $this->getDoctrine()->getManager();
      $em->persist($data);
      $em->flush();
        return new View("Task updated Successfully", Response::HTTP_CREATED);
    }  


}
