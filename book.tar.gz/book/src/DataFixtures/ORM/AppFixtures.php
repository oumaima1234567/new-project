<?php
namespace AppBundle\DataFixtures\ORM;

use AppBundle\Entity\Livre;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Common\Persistence\ObjectManager;

class AppFixtures extends Fixture
{
    public function load(ObjectManager $manager)
    {
        // create 20 products! Bam!
        
            $product = new Livre();
            $product->setTitre('java');
            $product->setDescriptif('dlm');
            $product->setISBN('rsd030');
            $product->setDatededition('27/02/2012');
            $product1 = new Livre();
            $product1->setTitre('oracle');
            $product1->setDescriptif('dlm');
            $product1->setISBN('rsd030');
            $product1->setDatededition('27/02/2014');
            $product3 = new Livre();
            $product3->setTitre('creation d un site web');
            $product3->setDescriptif('dlmff');
            $product3->setISBN('rsd030f');
            $product3->setDatededition('27/02/2013');
            $product2 = new Livre();
            $product2->setTitre('android');
            $product2->setDescriptif('dlmsd');
            $product2->setISBN('rsd0sd30');
            $product2->setDatededition('27/02/2017');
            
            $manager->persist($product);
            $manager->persist($product2);
            $manager->persist($product3);
            $manager->persist($product1);
        

        $manager->flush();
    }
}
?>